<?php include('server.php') ?>

<?php include ('inc/header.php'); ?>

 

   <section>
    <div class="container" style="padding-top:110px;">
      <div class="row align-items-center">
        <div class="col-lg-6 order-lg-2">
          <div class="p-5">
            <img class="img-fluid rounded-circle" src="img/stud2.jpg" alt="">
          </div>
        </div>
		<br/>
        <div class="col-lg-6 order-lg-1">
          <div class="p-5">
		  <h2 class="display-4">You're finally added to the list!</h2>
             <h3 class="display-6">Welcome to Excel Technical Skills and Career Center, Inc.!</h3>
            <p>We are excited to welcome you – our incoming and returning students – to the new academic year! Our learning center is energized by your arrival, and eager for the many opportunities the new year will bring.</p>
		<form>
		<a class="btn btn-primary" href="http://127.0.0.1/enroll/dashboard.php" role="button">Back to dashboard</a>
		
		</form>

          </div>
        </div>
      </div>
    </div>
  </section>



  <?php include ('inc/footer.php'); ?>
