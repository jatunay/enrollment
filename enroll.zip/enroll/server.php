<?php
session_start();

// initializing variables
$email    = "";
$errors = array(); 

// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'registration');

// REGISTER USER
if (isset($_POST['reg_user'])) {
  // receive all input values from the form
  $fname        = mysqli_real_escape_string($db, $_POST['firstname']);
  $lname        = mysqli_real_escape_string($db, $_POST['lastname']);
  $email        = mysqli_real_escape_string($db, $_POST['email']);
  $homenumber   = mysqli_real_escape_string($db, $_POST['homenumber']);
  $mobilenumber = mysqli_real_escape_string($db, $_POST['mobilenumber']);
  $password_1   = mysqli_real_escape_string($db, $_POST['password_1']);
  $password_2   = mysqli_real_escape_string($db, $_POST['password_2']);

  $gender           = mysqli_real_escape_string($db, $_POST['gender']);
  $birthdate        = mysqli_real_escape_string($db, $_POST['birthdate']);
  $address_street   = mysqli_real_escape_string($db, $_POST['address_street']);
  $address_street2  = mysqli_real_escape_string($db, $_POST['address_street2']);
  $address_city     = mysqli_real_escape_string($db, $_POST['address_city']);
  $address_region   = mysqli_real_escape_string($db, $_POST['address_region']);
  $address_postcode = mysqli_real_escape_string($db, $_POST['address_postcode']);
  $address_country  = mysqli_real_escape_string($db, $_POST['address_country']);

  // form validation: ensure that the form is correctly filled ...
  // by adding (array_push()) corresponding error unto $errors array
  if (empty($fname)) { array_push($errors, "Firstname is required"); }
  if (empty($lname)) { array_push($errors, "Lastname is required"); }
  if (empty($email)) { array_push($errors, "Email is required"); }
  if (empty($password_1)) { array_push($errors, "Password is required"); }
  if ($password_1 != $password_2) {
  array_push($errors, "Passwords do not match");
  }

  // first check the database to make sure 
  // a user does not already exist with the same username and/or email
  $user_check_query = "SELECT * FROM student_info WHERE email='$email' LIMIT 1";
  $result = mysqli_query($db, $user_check_query);
  $user = mysqli_fetch_assoc($result);
  
  if ($user) { // if user exists
    if ($user['email'] === $email) {
      array_push($errors, "The account you're trying to login already exists");
    }
  }

  // Finally, register user if there are no errors in the form
  if (count($errors) == 0) {
    $password = md5($password_1);//encrypt the password before saving in the database

    $query_adduser = "INSERT INTO student_info (email, password, firstname, lastname, phone_home, phone_mobile, gender, birthdate, address_street, address_street2, address_city, address_region, address_postcode, address_country) 
          VALUES('$email', '$password', '$fname', '$lname', '$homenumber', '$mobilenumber', '$gender', '$birthdate', '$address_street', '$address_street2', '$address_city', '$address_region', '$address_postcode', '$address_country')";
    mysqli_query($db, $query_adduser);
    // $_SESSION['currdata'] = "loggedin";
    // $_SESSION['success'] = "You are now logged in";
    // header('location: index.php');
    $query_getaddeduser = "SELECT * FROM student_info WHERE email='$email' LIMIT 1";
    $getaddeduser_result = mysqli_query($db, $query_getaddeduser);
    if (mysqli_num_rows($getaddeduser_result) == 1) {
      $_SESSION['currdata'] = mysqli_fetch_assoc($getaddeduser_result);
      $_SESSION['success'] = "You are now logged in";
      header('location: dashboard.php');
    }
  }
}

//ENROL USER
if (isset($_POST['enrol_user'])) {
  $course = mysqli_real_escape_string($db, $_POST['course']);
  $regemail = mysqli_real_escape_string($db, $_POST['email']);
  $query_insertcourse = "UPDATE student_info SET course='$course' WHERE email='$regemail'";
  mysqli_query($db, $query_insertcourse);
  $query_getuser = "SELECT * FROM student_info WHERE email='$regemail' LIMIT 1";
  $getuser_result = mysqli_query($db, $query_getuser);
  if (mysqli_num_rows($getuser_result) == 1) {
    $_SESSION['currdata'] = mysqli_fetch_assoc($getuser_result);
    $_SESSION['enrol_msg'] = "";
    header('location: accepted.php');
  }
}

// LOGIN USER
if (isset($_POST['login_user'])) {
  $email = mysqli_real_escape_string($db, $_POST['email']);
  $password = mysqli_real_escape_string($db, $_POST['password']);

  if (empty($email)) {
    array_push($errors, "Email is required");
  }
  if (empty($password)) {
    array_push($errors, "Password is required");
  }

  if (count($errors) == 0) {
    $password = md5($password);
    $query_getuser = "SELECT * FROM student_info WHERE email='$email' AND password='$password'";
    $results = mysqli_query($db, $query_getuser);
    if (mysqli_num_rows($results) == 1) {
      $_SESSION['currdata'] = mysqli_fetch_assoc($results);
      $_SESSION['email']    = $email;
      $_SESSION['success']  = "You are now logged in";
      header('location: dashboard.php');
    } else {
      array_push($errors, "Wrong username/password combination");
    }
  }
}

?>