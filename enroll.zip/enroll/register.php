<?php include('server.php') ?>

<?php include ('inc/header.php'); ?>

  <header class="masthead text-center text-white" style="background-image: url('img/bg.jpg'); background-repeat: no-repeat; background-size: cover; background-position: center center;">
    <div class="masthead-content" >
      <div class="container">
        <h2 class="masthead-heading mb-0">Register</h2>
             
      </div>
    </div>
   
  </header>

  <section>
    <div class="container">
      <div class="row align-items-center">
        <div class="col-lg-6 order-lg-2">
          <div class="p-5">
            <img class="img-fluid rounded-circle" src="img/stud1.jpg" alt="">
          </div>
        </div>
        <div class="col-lg-6 order-lg-1">
          <div class="p-5">
             <h2 class="display-4">Please Register:</h2>

<form method="post" action="register.php">
<?php include('error.php'); ?>
  <div class="form-row">
    <div class="form-group col-md-6">
      <label>First Name</label>
      <input type="text" name="firstname" value="<?=(isset($fname)) ? $fname : ''?>" placeholder="First Name" class="form-control">
    </div>
    <div class="form-group col-md-6">
      <label>Last Name</label>
      <input type="text" name="lastname" value="<?=(isset($lname)) ? $lname : ''?>" placeholder="Last Name" class="form-control">
    </div>
	<div class="form-group col-md-6">
      <label>Email</label>
      <input type="email" name="email" value="<?=(isset($email)) ? $email : ''?>" class="form-control" id="inputEmail4" placeholder="Email">
    </div>
	<div class="form-group col-md-6">
      <label>Home Number</label>
      <input type="text" name="homenumber" value="<?=(isset($homenumber)) ? $homenumber : ''?>" class="form-control" id="inputEmail4" placeholder="Home Number">
    </div>
		<div class="form-group col-md-6">
      <label>Mobile Number</label>
      <input type="text" name="mobilenumber" value="<?=(isset($mobilenumber)) ? $mobilenumber : ''?>" class="form-control" id="inputEmail4" placeholder="Home Number">
    </div>
	<div class="form-group col-md-6">
	<label>Gender</label>
     <div class="form-check">
  <input class="form-check-input" type="radio" name="gender" value="male" checked>
  <label class="form-check-label" for="exampleRadios1">
    Male
  </label>
</div>
<div class="form-check">
  <input class="form-check-input" type="radio" name="gender" value="female">
  <label class="form-check-label" for="exampleRadios2">
    Female
  </label>
</div>
    </div>
<div class="form-group col-md-6">
  <label>Birthdate</label>
  <input class="form-control" type="text" name="birthdate" value="<?=(isset($birthdate)) ? $birthdate : ''?>" id="example-datetime-local-input" placeholder="Birthdate">
  </div>
  </div>
  <div class="form-group">
    <label for="inputAddress">Address</label>
    <input class="form-control" id="inputAddress" placeholder="1234 Main St" type="text" name="address_street" value="<?=(isset($address_street)) ? $address_street : ''?>">
  </div>
  <div class="form-group">
    <label for="inputAddress2">Address 2</label>
    <input type="text" name="address_street2" value="<?=(isset($address_street2)) ? $address_street2 : ''?>" class="form-control" id="inputAddress2" placeholder="Apartment, studio, or floor">
  </div>
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputCity">City</label>
      <input type="text" name="address_city" value="<?=(isset($address_city)) ? $address_city : ''?>" class="form-control" id="inputCity" placeholder="City">
    </div>
	   <div class="form-group col-md-6">
      <label for="inputCity">Region</label>
      <input type="text" name="address_region" value="<?=(isset($address_region)) ? $address_region : ''?>" class="form-control" id="inputCity" placeholder="Region">
    </div>
    <div class="form-group col-md-4">
      <label for="inputCity">Country</label>
      <input type="text" name="address_country" value="<?=(isset($address_country)) ? $address_country : ''?>" class="form-control" id="inputCity" placeholder="Country">
    </div>
    <div class="form-group col-md-4">
      <label for="inputZip">Zip</label>
      <input type="text" name="address_postcode" value="<?=(isset($address_postcode)) ? $address_postcode : ''?>" class="form-control" id="inputZip" placeholder="Zip">
    </div>
	    <div class="form-group col-md-6">
      <label>Password</label>
      <input type="password" name="password_1" class="form-control" placeholder="Password">
    </div>
	    <div class="form-group col-md-6">
      <label>Confirm Password</label>
      <input type="password" name="password_2" placeholder="Confirm Password" class="form-control">
    </div>
  </div>

  <button type="submit" name="reg_user" class="btn btn-primary">Register</button>
</form>
          </div>
        </div>
      </div>
    </div>
  </section>
  
  

  <?php include ('inc/footer.php'); ?>
