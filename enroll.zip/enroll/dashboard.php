<?php include('server.php') ?>
<?php 
  // session_start(); 

  if (!isset($_SESSION['currdata'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['currdata']);
  	header("location: login.php");
  }

?>

<?php include ('inc/header.php'); ?>

  <header class="masthead text-center text-white" style="background-image: url('img/bg.jpg'); background-repeat: no-repeat; background-size: cover; background-position: center center;">
    <div class="masthead-content" >
      <div class="container">
        <h2 class="masthead-heading mb-0">Dashboard</h2>
             
      </div>
    </div>
   
  </header>

  <section>
    <div class="container">
      <div class="row align-items-center">
        <div class="col-lg-6 order-lg-2">
          <div class="p-5">
            <img class="img-fluid rounded-circle" src="img/student.jpg" alt="">
          </div>
        </div>
        <div class="col-lg-6 order-lg-1">
          <div class="p-5">
            
       	<div class="nav_control">
		<!-- logged in user information -->
	    <?php  if (isset($_SESSION['currdata'])) : ?>
		<h2 class="display-4">Welcome <strong><?php echo $_SESSION['currdata']['firstname']; ?></strong></h2>
	    
	    	<p> <a href="index.php?logout='1'"/>logout</a> </p>
	    <?php endif ?>
	</div>
	</div>
<div class="content">
  	<!-- notification message -->
  	<?php if (isset($_SESSION['success'])) : ?>
      <div class="error success" >
      	<h3>
          <?php 
          	echo $_SESSION['success']; 
          	unset($_SESSION['success']);
          ?>
      	</h3>
      </div>
  	<?php endif ?>
  	<?php if (isset($_SESSION['enrol_msg'])) : ?>
      <div class="error success" >
      	<h3>
          <?php 
          	echo $_SESSION['enrol_msg']; 
          	unset($_SESSION['enrol_msg']);
          ?>
      	</h3>
      </div>
  	<?php endif ?>
	<div class="bs-example">    
    <div class="list-group">
        <a class="list-group-item list-group-item-warning">
            <h2 class="display-6">Information and Courses:</h2>
        </a>
        <a href="#" class="list-group-item list-group-item-action">
            </i> First Name : <?php echo $_SESSION['currdata']['firstname']; ?>
        </a>
		 <a href="#" class="list-group-item list-group-item-action">
            Last Name : <?php echo $_SESSION['currdata']['lastname']; ?>
        </a>
		 <a href="#" class="list-group-item list-group-item-action">
            Email : <?php echo $_SESSION['currdata']['email']; ?>
        </a>
		 <a href="#" class="list-group-item list-group-item-action">
            Home Number : <?php echo $_SESSION['currdata']['phone_home']; ?>
        </a>
		 <a href="#" class="list-group-item list-group-item-action">
            Mobile Number : <?php echo $_SESSION['currdata']['phone_mobile']; ?>
        </a>
		 <a href="#" class="list-group-item list-group-item-action">
            Gender : <?php echo $_SESSION['currdata']['gender']; ?>
        </a>
			 <a href="#" class="list-group-item list-group-item-action">
            Birthdate : <?php echo $_SESSION['currdata']['birthdate']; ?>
        </a>
			 <a href="#" class="list-group-item list-group-item-action">
            Street : <?php echo $_SESSION['currdata']['address_street']; ?>
        </a>
			<a href="#" class="list-group-item list-group-item-action">
            Barangay : <?php echo $_SESSION['currdata']['address_street2']; ?>
        </a>
					<a href="#" class="list-group-item list-group-item-action">
            Region : <?php echo $_SESSION['currdata']['address_region']; ?>
        </a>
		<a href="#" class="list-group-item list-group-item-action">
            Zip : <?php echo $_SESSION['currdata']['address_postcode']; ?>
        </a>
		<a href="#" class="list-group-item list-group-item-action">
            Country : <?php echo $_SESSION['currdata']['address_country']; ?>
        </a>
		<a href="#" class="list-group-item list-group-item-action">
            Enrolled in : <?php echo $_SESSION['currdata']['course']; ?> class.
        </a>
        
    </div>
</div>
	
			<form method="post" action="accepted.php">
<br/>
  <div class="form-group">
      <h4 class="display-7">Courses Offered:</h4>
    <select name="course" class="form-control" id="exampleFormControlSelect1">
	  <option disabled <?=($_SESSION['currdata']['course'] == '') ? 'selected' : ''?> >Select a course</option>
      	<option value="Web Development Training" <?=($_SESSION['currdata']['course'] == 'Web Development Training') ? 'selected' : ''?> >Web Development Training</option>
  	  	<option value="Web Design" <?=($_SESSION['currdata']['course'] == 'Web Design') ? 'selected' : ''?> >Web Design</option>
  	  	<option value="Laravel" <?=($_SESSION['currdata']['course'] == 'Laravel') ? 'selected' : ''?> >Laravel</option>
  	  	<option value="Events Management Services" <?=($_SESSION['currdata']['course'] == 'Events Management Services') ? 'selected' : ''?> >Events Management Services</option>
    </select>
  </div>
    <div class="form-group">
    <label for="exampleFormControlInput1">Email address</label>
    <input class="form-control" type="email" name="email" value="<?=$_SESSION['currdata']['email']?>" placeholder="name@example.com">
  </div>
   <button type="submit" name="enrol_user" class="btn btn-primary">Enroll</button>
<br/><br/>
</form>
          </div>
        </div>
      </div>
    </div>
  </section>
  
  

 
  <?php include ('inc/footer.php'); ?>
