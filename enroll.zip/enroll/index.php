<?php include('server.php') ?>
<?php 
  // session_start(); 

  if (!isset($_SESSION['currdata'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['currdata']);
  	header("location: login.php");
  }

?>



  
<?php include ('inc/header.php'); ?>

  <header class="masthead text-center text-white" style="background-image: url('img/bg.jpg'); background-repeat: no-repeat; background-size: cover; background-position: center center;">
    <div class="masthead-content" >
      <div class="container">
        <h1 class="masthead-heading mb-0">Excel Technical Skills and Career Center</h1>
        <h4>A community of lifelong learners, responsible global citizens, and champions of our own success.</h4>
        <a href="http://127.0.0.1/enroll/register.php" class="btn btn-primary btn-xl rounded-pill mt-5">Enrollment Ongoing</a>
      </div>
    </div>
   
  </header>

  <section>
    <div class="container">
      <div class="row align-items-center">
        <div class="col-lg-6 order-lg-2">
          <div class="p-5">
            <img class="img-fluid rounded-circle" src="img/student.jpg" alt="">
          </div>
        </div>
        <div class="col-lg-6 order-lg-1">
          <div class="p-5">
            <h2 class="display-4">Excel Technical Skills and Career Center, Inc....</h2>
            <p> was established with the aim of providing quality IT Training that is affordable and usable for the students.</p>
          </div>
        </div>
      </div>
    </div>
  </section>
  
  



