<?php include('server.php') ?>

<?php include ('inc/header.php'); ?>



   <section>
    <div class="container">
      <div class="row align-items-center">
        <div class="col-lg-6 order-lg-2">
          <div class="p-5">
            <img class="img-fluid rounded-circle" src="img/stud3.jpg" alt="">
          </div>
        </div>
        <div class="col-lg-6 order-lg-1">
          <div class="p-5">
            <h2 class="display-4">Login</h2>

  <form method="post" action="login.php">
<?php include('error.php');  ?>
  <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <input name="email" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input name="password" type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
  </div>
  <button type="submit" class="btn btn-primary" name="login_user">Submit</button>
<p>
  		Not yet registered? <a href="register.php">Sign up</a>
  	</p>
</form>
          </div>
        </div>
      </div>
    </div>
  </section>
 
  
  <?php include ('inc/footer.php'); ?>
